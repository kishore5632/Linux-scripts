#!/bin/bash

# Script: x_window_basics.sh
