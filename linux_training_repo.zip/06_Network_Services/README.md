# Module 6: Network Services (Part I, II, III)

This module covers:
- DHCP, DNS, SSH setup and configuration
- File sharing using FTP, NFS, and Samba
- Web, mail, and proxy services using Apache, Sendmail, and Squid