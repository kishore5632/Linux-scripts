# Module 1: Automating Programs & Login Options

This module covers:
- Automating Linux programs with cron, at, batch
- Understanding runlevels and `/etc/rc.d`
- Configuring console, virtual, serial, and remote logins
- Secure login using SSH

Each script file demonstrates practical examples for hands-on learning.