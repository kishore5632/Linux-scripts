#!/bin/bash

# Script: automating_programs.sh
