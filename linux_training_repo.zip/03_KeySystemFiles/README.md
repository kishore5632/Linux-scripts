# Module 3: Key Filesystem Locations & /proc Pseudo Filesystem

This module covers:
- Important system directories: /boot, /etc, /var/log, /home
- Using and understanding the `/proc` filesystem
- Modifying kernel settings with `sysctl`