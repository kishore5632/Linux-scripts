#!/bin/bash

# Script: proc_filesystem.sh
