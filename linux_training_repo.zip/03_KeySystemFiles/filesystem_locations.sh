#!/bin/bash

# Script: filesystem_locations.sh
