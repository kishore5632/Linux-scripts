#!/bin/bash

# Script: hardware_mgmt.sh
