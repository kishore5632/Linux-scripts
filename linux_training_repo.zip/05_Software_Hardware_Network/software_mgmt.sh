#!/bin/bash

# Script: software_mgmt.sh
