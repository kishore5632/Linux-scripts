# Module 2: Kernel Building & GNU/Linux Filesystem

This module covers:
- Building and testing a custom Linux kernel
- Exploring kernel source, configuration, and patches
- Linux partitioning, filesystem types, mounting, and automount