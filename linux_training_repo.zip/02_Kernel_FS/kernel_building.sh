#!/bin/bash

# Script: kernel_building.sh
