#!/bin/bash

# Script: gnu_linux_filesystem.sh
