# Module 4: Bash Shell & User Management

This module covers:
- Key Bash commands from `/bin` and `/sbin`
- Shell history, vi editor, man/info pages
- User/group management, passwords, PAM, quotas, NIS basics